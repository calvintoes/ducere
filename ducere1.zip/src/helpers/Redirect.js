export const redirect = (response) => {
  window.location = response.redirect;
};