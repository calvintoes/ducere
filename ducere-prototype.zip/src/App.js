import React from 'react';
import './App.css';
import LoginContainer from './containers/LogInContainer'

function App() {

  // const store = createStore();
  
  return (
    <div className="App">
     <LoginContainer />
    </div>
  );
}

export default App;
